function [Phi,Q]=flatblockctrd(x,y,kx,ky,FH,Q)
% function [Phi,Q]=flatblockctrd(x,y,kx,ky,FH,Q)
% Defines and solves a 2D block-centred finite difference model
% x,y mesh coordinates, kx,ky conductivities, FH=fixed heads (NaN for ordinary points) Q=fixed nodal flows
% Phi is computed heads, Q computed nodal balances
%
% TO 991017

HUGE=1e20;

x=x(:)';  xM=(x(1:end-1)+x(2:end))/2;
y=y(:);   yM=(y(1:end-1)+y(2:end))/2;

Nx=length(xM);  Ny=length(yM);

dx=diff(x);    dy=diff(y); if y(end)<y(1), dy=-dy; end

if isempty(FH),  FH=NaN*zeros(Ny,Nx); end; FH=FH(:);
if isempty( Q),   Q=    zeros(Ny,Nx); end;  Q= Q(:);

% node numbering
Nodes = reshape([1:Nx*Ny],Ny,Nx);
Il=Nodes(:,2:end);   Jl=Nodes(:,1:end-1);
Ir=Nodes(:,1:end-1); Jr=Nodes(:,2:end);
It=Nodes(2:end,:);   Jt=Nodes(1:end-1,:);
Ib=Nodes(1:end-1,:); Jb=Nodes(2:end,:);

[DX,DY]=meshgrid(dx,dy);

RH=0.5*DX./DY./kx;  ex=1./(RH(:,1:end-1)+RH(:,2:end));
RV=0.5*DY./DX./ky;  ey=1./(RV(1:end-1,:)+RV(2:end,:));

A=-sparse([Il(:);Ir(:);It(:);Ib(:)],...
          [Jl(:);Jr(:);Jt(:);Jb(:)],...
          [ex(:);ex(:);ey(:);ey(:)],Ny*Nx,Ny*Nx,5*Ny*Nx);
Adiag= -sum(A,2);

% Boundary conditions, just Q and Fixed Heads right now
isFxHd=HUGE* ~isnan(FH);
FH(~isFxHd)=0;

Phi=spdiags(isFxHd + ~isFxHd.*Adiag,0,A)\(isFxHd.*FH + ~isFxHd.*Q);

Q=spdiags(Adiag,0,A)*Phi;

Q  =reshape(Q,Ny,Nx);
Phi=reshape(Phi,Ny,Nx);
