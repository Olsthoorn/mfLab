function [phi,q,s,X,x,kD,c,h,Q]=nsecn(x,kD,c,h,Q,X)
% USAGE: [phi,q,s]=nsecn(x,kD,c,h,Q,X)
% USAGE: [phi,q,s[,X[,x[,kD[,c[,h[,Q]]]]]]=nsecn(x,kD,c[,h[,Q[,X]]])
%
% Analytic one-dimensional Mazure solution for nLayers and n-connected sections (using Matrix functions).
% Left and right most sections run to -inf and +inf resp.
%
% input:
%  x, (nNod by  1  ) vector of coordinates of intersection points
% kD, (nLay by nSec) matrix of transmissivity values
%  c, (nLay by nSec) matrix of vertical resistance values of overlaying aquitards
%  h, ( 1   by nSec) vector of given head on top of each sections
%  Q, (nNod by nSec) matrix of nodal injections [L2/T]
%  X,  a vector of point where head phi and flow will be computed
%
%  output:
%  phi computed heads [H]    a (nLay by length(X)) matrix
%  q   computed flows [L2/T] a (nLay by length(X)) matrix
%  s   [L/T] is the downward positive seepage rate through top of each layer, a (nLay by length(X) matrix
%  X   is sorted X or 10 points within each inner section when omitted or empty in the input
%  The other outputs equal the inputs, x is sorted and kD, c,h, Q are augmented if necessary
%     these outputs may be utilised to fill out simplified inputs or generate X
%  if Q is empty,  0 will be used for all nodes and layers, a single value per layer is accepted
%  if h is empty,  0 will be used for all sections
%  if c or kD are empty an error message is generated
%  if colmns of c and kD will be added to the right, but a value for each layer is necessary
%  if number of columns of c, kD, h or Q are > than follows from length(x) an error message is generated 
%
% T.N.Olsthoorn 990505, 1500h

if nargin<6; X=[]; end
if nargin<5; Q= 0; end
if nargin<4; h= 0; end

if nargin<3 | isempty( c); error('ERROR nsecn:  c must be specified!'); end
if nargin<2 | isempty(kD); error('ERROR nscen: kD must be specified!'); end
if nargin<1; help('nsecn'); return; end


[x,kD,c,h,Q,nLay,nSec,nNod,X]=checkInput(x,kD,c,h,Q,X);
H  =ones(nLay,1)*h;

% all points including of the outer sections to infinity!
Q=[ zeros(nLay,1), Q, zeros(nLay,1)];
x=[   -inf,        x,     inf      ]; Nx=length(x);

% MidSection points are used to compute relative coordinates within sections
xMidSec=0.5*(x(1:end-1)+x(2:end)); xMidSec(1)=x(2); xMidSec(end)=x(end-1);

% system matrices for all sections
A=[];
for iSec=1:nSec
   a=1./(kD(:,iSec).* c(:,iSec));
   b=1./(kD(:,iSec).*[c(2:nLay,iSec);inf]);
   A(:,:,iSec)=diag(a+b)-diag(a(2:nLay),-1)-diag(b(1:nLay-1),1);
end

% Generating and filling the total coefficient matrix
C=zeros(nLay*(2*(Nx-2)),nLay*(2*(Nx-2)+2));			% Coefficient matrix
R=zeros(nLay*(2*(Nx-2)),1);								% Right hand side vector
for i=1:nNod
   % i is nNodNr and number of left section of each node
   % j is number of right section of each node
   % ii and jj point to the position within the total coefficient matrix
   j=i+1;
   ii=2*nLay*(i-1)+1;
   jj=ii+nLay-1;
   C(ii:jj,ii       :jj       )=+expm(-(x(j)-xMidSec(i))*sqrtm(A(:,:,i)));
   C(ii:jj,ii+  nLay:jj+  nLay)=+expm(+(x(j)-xMidSec(i))*sqrtm(A(:,:,i)));
   C(ii:jj,ii+2*nLay:jj+2*nLay)=-expm(-(x(j)-xMidSec(j))*sqrtm(A(:,:,j)));
   C(ii:jj,ii+3*nLay:jj+3*nLay)=-expm(+(x(j)-xMidSec(j))*sqrtm(A(:,:,j)));
	R(ii:jj)=-H(:,i)+H(:,j);   
   C(ii+nLay:jj+nLay,ii       :jj       )  =-diag(kD(:,i))*sqrtm(A(:,:,i))*expm(-(x(j)-xMidSec(i))*sqrtm(A(:,:,i)));
   C(ii+nLay:jj+nLay,ii+  nLay:jj+  nLay)  =+diag(kD(:,i))*sqrtm(A(:,:,i))*expm(+(x(j)-xMidSec(i))*sqrtm(A(:,:,i)));
   C(ii+nLay:jj+nLay,ii+2*nLay:jj+2*nLay)  =+diag(kD(:,j))*sqrtm(A(:,:,j))*expm(-(x(j)-xMidSec(j))*sqrtm(A(:,:,j)));
   C(ii+nLay:jj+nLay,ii+3*nLay:jj+3*nLay)  =-diag(kD(:,j))*sqrtm(A(:,:,j))*expm(+(x(j)-xMidSec(j))*sqrtm(A(:,:,j)));
   R(ii+nLay:jj+nLay)=Q(:,j);
end

% Solve the system, using all layers and leaving out the outer nLay columns
% These have no freedom, because the sectons run to infinity. COEF(1:nLay) and COEF(end-nLay:end) must be zero.
COEF=C(:,nLay+1:end-nLay)\R;	COEF=[zeros(nLay,1);COEF;zeros(nLay,1)];

phi=zeros(nLay,length(X));			% heads
q  =zeros(nLay,length(X));			% flow [L2/T]
s  =zeros(nLay,length(X));			% seepage upward [L/T]
for i=1:length(X)
   iSec=find(X(i)>x(1:end-1) & X(i)<=x(2:end));			% Section in which point x(i) falls
   k=2*nLay*(iSec-1)+1;			l=k+nLay-1;					% k:l indices in COEF matrix for this section
   
   RA=sqrtm(A(:,:,iSec));
   T =diag(kD(:,iSec));
   
   % compute head and flow for this point
   C1=expm(-(X(i)-xMidSec(iSec))*RA)*COEF(k:l);
   C2=expm(+(X(i)-xMidSec(iSec))*RA)*COEF(k+nLay:l+nLay);
   C3=RA*C1;
   C4=RA*C2;

   phi(:,i)=C1+C2+H(:,iSec);										% phi  [L   ],  heads
   q  (:,i)=T   *( C3-C4);		% q    [L2/T],  specific flow, -kD(dphi/dx)
   sNet    =T*RA*(-C3-C4);		% s    [L /T],  seepage(dq/dx)
   % compute seepage through top of each aquifer, starting at lowest aquifer upward
   s(nLay,i)=sNet(nLay); for iLay=nLay-1:-1:1; s(iLay,i)=sNet(iLay)+s(iLay+1,i); end
%   fi=[h(iSec);phi(:,i)];
%   for iLay=1:nLay, ss(iLay,i)=(fi(iLay)-fi(iLay+1))/c(iLay,iSec); end  % checking correctness of s
end
i=0; % comment
function [x,kD,c,h,Q,nLay,nSec,nNod,X]=checkInput(x,kD,c,h,Q,X);
nNod=length(x);
nSec=length(x)+1;
nLay=size  (kD,1);

x=sort(x(:)');
if isempty(X);
   J=0:9;  dx=diff(x)/10;
   for i=1:nNod-1;
      X=[X,[x(i)+J*dx(i)]];
   end
else
   X=X(:)';
end

if isempty(Q); Q=0; end
if isempty(h); h=0; else  h=h(1,:); end

if size( c,1)~=nLay; error('kD and c have different number of layers!'); end
if size( c,2)>nSec; error('Too many  c-sections, compared to number of x-values!'); end
if size(kD,2)>nSec; error('Too many kD-sections, compared to number of x-values!'); end
if size( h,2)>nSec; error('Too many  h-sections, compared to number of x-values!'); end
if size( Q,2)>nNod; error('Too many    Q-points, compared to number of x-values!'); end

ns=size(kD,2); for is=ns+1:nSec; kD( :,is)=kD(:,ns); end;		% augment kD if necessary
ns=size( c,2); for is=ns+1:nSec;  c( :,is)= c(:,ns); end;		% augment  c if necessary
ns=size( h,2); for is=ns+1:nSec;  h( 1,is)= h(1,ns); end;      % augment  h if necessary
nl=size( Q,1); for il=nl+1:nLay;	 Q(il, :)= Q(nl,:); end;		% augment  Q is necessary
ns=size( Q,2); for is=ns+1:nNod;	 Q( :,is)= Q(ns,:); end;		% augment  Q is necessary

function [x,kD,c,h,Q]=testinput
% TEST 1
   x =[  -2000 -1500 -1000 -500  0    500 1000 1500 2000  ];
h = [  -2     2    -2    2   -2    2   -2    2   -2    2];
c =[[ 250   250   250  250  250  250  250  250  250  250];...
    [ 250   250   250  250  250  250  250  250  250  250];...
    [ 250   250   250  250  250  250  250  250  250  250]];
kD=[[ 500   500   500  500  500  500  500  500  500  500];...
    [ 500   500   500  500  500  500  500  500  500  500];...
    [ 500   500   500  500  500  500  500  500  500  500]];
Q =[[    0     0     0    0    0     0     0    0  0    ];...
    [    0     0     0    0    0     0     0    0  0    ];...
    [    0     0     0    0    0     0     0    0  0    ]];
