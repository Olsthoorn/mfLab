function shownsecn(phi,q,s,z,h,X,x)
% show results of nsec arb
% TO 000112

dd=[0.0001 0.0002 0.0005 0.001 0.002 0.005 0.01 0.02 0.05 0.1 0.2 0.5 1 2 5 10 20 50 100 200 500 1000 2000 5000 10000];

figure;
a1=subplot(3,1,1); hold on; grid on; ylabel('[m]');    title('heads in all aquifers');
a2=subplot(3,1,2); hold on; grid on; ylabel('[m2/d]'); title('flux, positive = --> (black is total q)');
a3=subplot(3,1,3); hold on; grid on; ylabel('[m/d]');  title('seepage from top'); xlabel('x [m]');

figure;
b1=axes; hold on; xlabel('x [m]'); ylabel('x [m]'); title('head- and streamlines');

axes(a1); plot(X,phi); xh=[[min(x(2),X(1)),x(2:end-1)];[x(2:end-1),max(x(end-1),X(end))]]; hh=[h;h]; plot(xh(:),hh(:))
hold on
axes(a2); plot(X,q); plot(X,sum(q,1),'k');
hold on
axes(a3); plot(X,s);
hold on
axes(b1);


H=zeros(size(X)); for i=1:length(x)-1,    H(find(X>=x(i) & X<=x(i+1)))=h(i); end

mPsi=min(0,min(sum(q,1))); MPsi=max(0,max(sum(q,1)));
mPhi=min([phi(:);h(:)]);   MPhi=max([phi(:);h(:)]);
mPsi=floor(mPsi); MPsi=ceil(MPsi); dPsi=(MPsi-mPsi)/50; dPsi=dd(max(find(dPsi>=dd))); psirange=mPsi:dPsi:MPsi;
mPhi=floor(mPhi); MPhi=ceil(MPhi); dPhi=(MPhi-mPhi)/50; dPhi=dd(max(find(dPhi>=dd))); phirange=mPhi:dPhi:MPhi;

cont(phi,q,X,z,H,psirange,phirange);
axes(b1); title(sprintf('head- and streamlines, dPhi=%f m, dPsi=%f m2/d',dPhi,dPsi));

function cont(phi,q,x,z,H,psirange,phirange)
N=length(phi(:,1));
Phi=zeros(2*N+1,length(x));
Psi=zeros(2*N+1,length(x));

Q=flipud(cumsum(flipud(q),1));
Psi(1:2:2*N-1,:)= Q;
Psi(2:2:2*N,  :)= Q;
Psi(2*N+1,    :)=zeros(size(Q(end,:)));
Phi(1,        :)= H;
Phi(2:2:2*N,  :)= phi;
Phi(3:2:2*N+1,:)= phi;

for i=1:2:length(z)-1
   patch([x(1),x(end),x(end),x(1)],[z(i),z(i),z(i+1),z(i+1)],[0.9,0.9,0.9]);
end
line([x(1),x(end)],[z(end),z(end)],'color','k','linewidth',3);
contour(x,z,Phi,phirange,'r');
contour(x,z,Psi,psirange,'b');
line(x,H,'color','r','linewidth',1);
